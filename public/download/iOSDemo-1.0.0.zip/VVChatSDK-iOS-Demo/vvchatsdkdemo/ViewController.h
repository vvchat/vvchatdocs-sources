//
//  ViewController.h
//  vvchatsdkdemo
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)isInstallVVChatPressed:(id)sender;

-(IBAction)AuthPressed:(id)sender;
- (IBAction)sharePressed:(id)sender;
- (IBAction)advanceShare:(id)sender;

@end

