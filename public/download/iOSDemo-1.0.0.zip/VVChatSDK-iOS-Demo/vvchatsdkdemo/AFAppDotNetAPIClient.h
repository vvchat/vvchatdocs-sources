//
//  AFAppDotNetAPIClient.h
//  vvchatsdkdemo
//
//  Created by tt on 2018/3/16.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
@interface AFAppDotNetAPIClient : AFHTTPSessionManager
+ (instancetype)sharedClient;
@end
