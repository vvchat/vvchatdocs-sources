//
//  VVChatSDK.h
//  VVChatSDK
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol VVChatDelegate <NSObject>

@optional
/**
 type: 类型 第三方登录为 thirdlogin  支付为qpay
 status: 状态 success 为成功 其他为失败
 data: 成功状态 为对应的业务数据 如果失败 包含err_msg字段
**/
-(void) onResp:(NSString*)type status:(NSString*)status data:(NSDictionary*)data;
@end


@interface VVChatSDK : NSObject
/**
 设置模式。0.生产模式 1.开发模式 默认0
 **/
+(void) setMode:(int)mode;

/**
 注册APP
 appId: vvchat开发平台申请的应用ID
 **/
+(BOOL) registerApp:(NSString *)appId;
/**
 授权
 appId: 应用ID
 scope: 作用域 获取用户信息的作用域为snsapi_userinfo
 state: 状态码，第三方应用传过来的，SDK将原样返回 第三方可以通过此字段做安全校验
 **/
+(void) auth:(NSString*)appId scope:(NSString*)scope state:(NSString*)state DEPRECATED_ATTRIBUTE;

+(void) auth:(NSString*)scope state:(NSString*)state;

/***
 支付
 imprestCode：预付款编号
 **/
+(void) pay:(NSString*)imprestCode;

/***
 基础分享
 shareTitle: 标题
 subTitle: 副标题的描述
 shareUrl: 分享的链接
 shareThumbUrl:分享的预览图片(图片预览)
 **/
+(void)share:(NSString*)shareTitle subTitle:(NSString*)subTitle shareUrl:(NSString*)shareUrl shareThumbUrl:(NSString*)shareThumbUrl;

/***
 高级分享
 shareTitle: 标题
 subTitle: 副标题的描述
 shareUrl: 分享的链接
 shareThumbUrl:分享的预览图片(图片预览)
 shareDataUrl: 高级分享的模版数据  类型为json的字符串
 **/
+(void)advancedSharing:(NSString*)shareTitle subTitle:(NSString*)subTitle shareUrl:(NSString*)shareUrl shareThumbUrl:(NSString*)shareThumbUrl shareDataUrl:(id)shareDataUrl;

/**
 是否已安装vvchat
 **/
+(BOOL) isInstalled;

/**
  处理VVChat通过URL启动App时传递的数据
 **/
+(BOOL) handleOpenURL:(NSURL *) url delegate:(id<VVChatDelegate>) delegate;
@end
