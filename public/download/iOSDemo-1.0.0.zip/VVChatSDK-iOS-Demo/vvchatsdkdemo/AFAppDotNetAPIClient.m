//
//  AFAppDotNetAPIClient.m
//  vvchatsdkdemo
//
//  Created by tt on 2018/3/16.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import "AFAppDotNetAPIClient.h"
static NSString * const AFAppDotNetAPIBaseURLString = @"http://dev.vvchat.im/";

@implementation AFAppDotNetAPIClient
+ (instancetype)sharedClient {
    static AFAppDotNetAPIClient *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[AFAppDotNetAPIClient alloc] initWithBaseURL:[NSURL URLWithString:AFAppDotNetAPIBaseURLString]];
        _sharedClient.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    });
    
    return _sharedClient;
}
@end
