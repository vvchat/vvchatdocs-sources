//
//  ViewController.m
//  vvchatsdkdemo
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import "ViewController.h"
#import "VVChatSDK.h"
#import "VVChatPayViewController.h"
#import "AFAppDotNetAPIClient.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(IBAction)isInstallVVChatPressed:(id)sender{
    NSString *msg = @"";
    if ([VVChatSDK isInstalled]){
        msg = @"已安装了VVChat！";
        
    }else{
        msg = @"未安装VVChat！";
    }
    // 创建
    
    UIAlertController *alertview=[UIAlertController alertControllerWithTitle:@"提示" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *defult = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertview addAction:cancel];
    [alertview addAction:defult];
    
    [self presentViewController:alertview animated:YES completion:nil];
}

-(IBAction)AuthPressed:(id)sender{
    [VVChatSDK auth:@"snsapi_userinfo" state:@"dsdaasdfsdf"];
}

- (IBAction)sharePressed:(id)sender {
    [VVChatSDK share:@"Objective-C编程之道(豆瓣)Objective-C编程之道 (豆瓣)Objective-C编程之道 (豆瓣)Objective-C编程之道 (豆瓣)Objective-C编程之道 (豆瓣)Objective-C编程之道 (豆瓣)" subTitle:@"OS设计模式解析OS设计模式解析OS设计模式解析OS设计模式解析OS设计模式解析OS设计模式解析OS设计模式解析OS设计模式解析" shareUrl:@"https://book.douban.com/subject/6920082/" shareThumbUrl: @""];
}

- (IBAction)advanceShare:(id)sender {
  NSDictionary * dataDict =@{
      @"tpl_header":@"vctalk",
      @"tpl_version":@"v1",
      @"tpl_type":@"MultipleLine",
      @"data":@[@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职"]
      };
    NSArray * array = @[@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职",@"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强",@"大出血！印度耗资37.5亿与中国“抢”尼泊尔",@"空军司令提出购买F35战机方案 却被国家免职"];
    NSString * str = @"巴斯22+15哈神制胜抢断 辽宁3-1淘汰首钢进四强";
    [VVChatSDK advancedSharing:@"vvchat"
                      subTitle:@"棋牌游戏房间开始预定了"
                      shareUrl:@"https://book.douban.com/subject/6920082/"
                  shareThumbUrl: @"http://img.zcool.cn/community/0142135541fe180000019ae9b8cf86.jpg@1280w_1l_2o_100sh.png"
                  shareDataUrl:str];

}
-(IBAction)ToPayVC:(id)sender{
    
    [[AFAppDotNetAPIClient sharedClient] GET:@"paybusapi/v1/test/imprest" parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"responseObject=%@",responseObject);
        [VVChatSDK pay:responseObject[@"imprest_code"]];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"err=%@",error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
