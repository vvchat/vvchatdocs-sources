this.vvchat ={}
// 错误回调函数
this.errCallbackFunc;
// 配置
this.config = {};

//iOS  注册事件监听
function setupWebViewJavascriptBridge(callback) {

    if (window.WebViewJavascriptBridge) {
        return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'https://__bridge_loaded__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function () {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
}

//android 注册事件监听
function connectWebViewJavascriptBridge(callback) {

    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
    } else {
        document.addEventListener(
            'WebViewJavascriptBridgeReady'
            , function() {
                callback(WebViewJavascriptBridge)
            },
            false
        );
    }
}


/**
// config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，
config是一个客户端的异步操作，
所以如果需要在页面加载时就调用相关接口，
则须把相关接口放在ready函数中调用来确保正确执行。
对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
**/
vvchat.onReady = function (callback) {

    setupWebViewJavascriptBridge(function(bridge) {
        window.QJSBridge = bridge
        callback()
    })

    connectWebViewJavascriptBridge(function(bridge) {
        bridge.init(function(message, responseCallback) {
            responseCallback();
        });
        window.QJSBridge = bridge
        callback()
    })
}

/**
通过config接口注入权限验证配置
所有需要使用JS-SDK的页面必须先注入配置信息，否则将无法调用
（同一个url仅需调用一次，对于变化url的SPA的web app可在每次url变化时进行调用）。
**/
vvchat.config = function (vvchatConfig) {
    this.config = vvchatConfig;
}

vvchat.onError = function (errFunc) {
    this.errCallbackFunc = errFunc;
}

/**
  调用方法
  method: 方法名
  options 参数
  successCallback: 成功回调
  errorCallback：错误回调
  completeCallback: 完成回调
**/
vvchat.call = function(method,options,successCallback,errorCallback,completeCallback){
    if (window.QJSBridge) {
        window.QJSBridge.callHandler(method,options, function (response) {
            let result = JSON.parse(response)
            if (result.err_code==undefined || result.err_code == 200) { // 正确请求
                if (successCallback) {
                    successCallback(result)
                }
            }else{
                // 错误
                if (errorCallback) {
                    errorCallback(result)
                }
            }
            // 完成
            if (completeCallback) {
                completeCallback(result)
            }
        })
    }
}