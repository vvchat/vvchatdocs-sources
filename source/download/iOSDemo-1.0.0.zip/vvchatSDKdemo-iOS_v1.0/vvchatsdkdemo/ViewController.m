//
//  ViewController.m
//  vvchatsdkdemo
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import "ViewController.h"
#import "VVChatSDK.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(IBAction)isInstallVVChatPressed:(id)sender{
    NSString *msg = @"";
    if ([VVChatSDK isInstalled]){
        msg = @"已安装了VVChat！";
        
    }else{
        msg = @"未安装VVChat！";
    }
    // 创建
    
    UIAlertController *alertview=[UIAlertController alertControllerWithTitle:@"提示" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *defult = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertview addAction:cancel];
    [alertview addAction:defult];
    
    [self presentViewController:alertview animated:YES completion:nil];
}

-(IBAction)AuthPressed:(id)sender{
    [VVChatSDK auth:@"test" scope:@"snsapi_userinfo" state:@"dsdaasdfsdf"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
