//
//  AppDelegate.h
//  vvchatsdkdemo
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VVChatSDK.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate,VVChatDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

