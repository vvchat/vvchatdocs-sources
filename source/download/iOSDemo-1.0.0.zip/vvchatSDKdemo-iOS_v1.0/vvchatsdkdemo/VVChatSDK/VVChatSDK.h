//
//  VVChatSDK.h
//  VVChatSDK
//
//  Created by chenyisi on 2018/1/15.
//  Copyright © 2018年 aiti. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol VVChatDelegate <NSObject>

@optional
/**
 type: 类型 第三方登录为 thirdlogin  支付为qpay
 status: 状态 success 为成功 其他为失败
 data: 成功状态 为对应的业务数据 如果失败 包含err_msg字段
**/
-(void) onResp:(NSString*)type status:(NSString*)status data:(NSDictionary*)data;
@end

@interface VVChatSDK : NSObject

/**
 注册APP
 appId: vvchat开发平台申请的应用ID
 **/
+(BOOL) registerApp:(NSString *)appId;
/**
 授权
 appId: 应用ID
 scope: 作用域 获取用户信息的作用域为snsapi_userinfo
 state: 状态码，第三方应用传过来的，SDK将原样返回 第三方可以通过此字段做安全校验
 **/
+(void) auth:(NSString*)appId scope:(NSString*)scope state:(NSString*)state;

/**
 是否已安装vvchat
 **/
+(BOOL) isInstalled;

/**
  处理VVChat通过URL启动App时传递的数据
 **/
+(BOOL) handleOpenURL:(NSURL *) url delegate:(id<VVChatDelegate>) delegate;
@end
